'use client'

import { useRouter } from '@bprogress/next/app'
import { format } from 'date-fns'
import { Field, FieldArray, Form, Formik } from 'formik'
import { CalendarIcon, Plus, Trash } from 'lucide-react'
import { useState } from 'react'
import { z } from 'zod'
import { PageHeader } from '@/components/layout/PageHeader'
import { SectionContainer } from '@/components/layout/SectionContainer'
import { Button } from '@/components/ui/button'
import { Calendar } from '@/components/ui/calendar'
import { Input } from '@/components/ui/input'
import { MultiSelectCombobox } from '@/components/ui/multi-select-combobox'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Switch } from '@/components/ui/switch'
import { useConfirmationDialog } from '@/hooks/use-confirmation-dialog'
import { createPromotion } from '@/lib/mutations/promotions/create/create'
import { updatePromotion } from '@/lib/mutations/promotions/update/update'
import { cn, validateWithZod } from '@/lib/utils'
import AmountInput from '../ui/amount-input'
import { SelectField } from '../ui/select-field'

interface PromotionResponse {
  id: string
  employeeId: string
  newJobTitle: string
  newJobTitleId: string
  newJobGradeId?: string
  newJobGrade?: string
  newDepartmentId?: string
  newDepartment?: string
  newZoneId?: string
  newZone?: string
  newBranchId?: string
  newBranch?: string
  newSalary: number
  effectiveDate: string
  includesTransfer: boolean
  allowances: {
    allowanceType: string
    amount: number
  }[]
  approverEmployeeIds?: string[]
  emailsToNotifyUponApproval?: string[]
}

interface PromotionRequestPayload {
  employeeIds: string[]
  newJobTitle: string
  newJobTitleId?: string
  newJobGradeId?: string
  newJobGrade?: string
  newDepartmentId?: string
  newDepartment?: string
  newZoneId?: string
  newZone?: string
  newBranchId?: string
  newBranch?: string
  newSalary: number
  effectiveDate: string
  includesTransfer: boolean
  approverEmployeeIds: string[]
  emailsToNotifyUponApproval: string[]
}

interface FormValues extends PromotionRequestPayload {
  [key: string]: unknown
}

interface SelectOption {
  value: string
  label: string
  image?: string
}

// Date Picker Component
interface DatePickerFieldProps {
  label: string
  value: string
  onSelect: (date: string) => void
  error?: string
  required?: boolean
}

const DatePickerField = ({ label, value, onSelect, error, required }: DatePickerFieldProps) => {
  const [open, setOpen] = useState(false)
  const currentYear = new Date().getFullYear()
  const selectedDate = value ? new Date(value) : undefined
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-slate-700">
        {label}
        {required && <span className="text-destructive ml-1">*</span>}
      </label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            type="button"
            className={cn(
              'w-full border-[#e5e5e5] justify-start text-left font-normal',
              !value && 'text-muted-foreground',
              error && 'border-destructive'
            )}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {value ? format(new Date(value), 'PPP') : <span>Pick a date</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            captionLayout="dropdown"
            startMonth={new Date(currentYear, 0)}
            endMonth={new Date(currentYear + 10, 11)}
            selected={selectedDate}
            onSelect={(date) => {
              if (date) {
                onSelect(format(date, 'yyyy-MM-dd'))
                setOpen(false)
              }
            }}
            disabled={(date) => date < today}
          />
        </PopoverContent>
      </Popover>
      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  )
}

interface PromotionsFormProps {
  initialData?: PromotionResponse | null
  /** Pre-selected employees coming from the roster (create flow). */
  initialEmployeeIds?: string[]
  employeeOptions: SelectOption[]
  departmentOptions: SelectOption[]
  zoneOptions: SelectOption[]
  branchOptions: SelectOption[]
  jobGradeOptions: SelectOption[]
  designationOptions: SelectOption[]
}

const zodSchema = z.object({
  employeeIds: z
    .array(z.string())
    .refine((val) => val.filter((id) => id.trim() !== '').length >= 1, {
      message: 'Select at least one employee',
    }),
  newJobTitle: z.string().min(1, 'New Job title is required'),
  newJobTitleId: z.string().min(1, 'New Job title is required'),
  newJobGradeId: z.string().min(1, 'Job grade is required'),
  newJobGrade: z.string().min(1, 'Job grade is required'),
  newDepartmentId: z.string().min(1, 'Department is required'),
  newDepartment: z.string().min(1, 'Department is required'),
  newZoneId: z.string().min(1, 'Zone is required'),
  newZone: z.string().min(1, 'Zone is required'),
  newBranchId: z.string().min(1, 'Branch is required'),
  newBranch: z.string().min(1, 'Branch is required'),
  newSalary: z.preprocess(
    (val) => Number(String(val).replace(/,/g, '')),
    z.number().min(1, 'Salary must be 1 or greater')
  ),
  effectiveDate: z.string().min(1, 'Effective date is required'),
  includesTransfer: z.boolean(),

  approverEmployeeIds: z
    .array(z.string())
    .refine((val) => val.filter((id) => id.trim() !== '').length >= 1, {
      message: 'At least one approver is required.',
    }),

  emailsToNotifyUponApproval: z
    .array(z.string())
    .refine((val) => val.filter((email) => email.trim() !== '').length >= 1, {
      message: 'At least one department or email must be provided.',
    }),
})

const PromotionsForm = ({
  initialData = null,
  initialEmployeeIds = [],
  employeeOptions,
  departmentOptions,
  zoneOptions,
  branchOptions,
  jobGradeOptions,
  designationOptions,
}: PromotionsFormProps) => {
  const { push } = useRouter()
  const confirmationDialog = useConfirmationDialog()

  // Edit mode targets a single record; create mode may target many (from roster).
  const initialEmployees = initialData?.employeeId
    ? [initialData.employeeId]
    : initialEmployeeIds

  const initialValues: FormValues = {
    employeeIds: initialEmployees,
    newJobTitle: initialData?.newJobTitle ?? '',
    newJobTitleId: initialData?.newJobTitleId ?? '',
    newJobGradeId: initialData?.newJobGradeId ?? '',
    newJobGrade: initialData?.newJobGrade ?? '',
    newDepartmentId: initialData?.newDepartmentId ?? '',
    newDepartment: initialData?.newDepartment ?? '',
    newZoneId: initialData?.newZoneId ?? '',
    newZone: initialData?.newZone ?? '',
    newBranchId: initialData?.newBranchId ?? '',
    newBranch: initialData?.newBranch ?? '',
    newSalary: initialData?.newSalary ?? 0,
    effectiveDate: initialData?.effectiveDate ?? '',
    includesTransfer: initialData?.includesTransfer ?? false,

    approverEmployeeIds: initialData?.approverEmployeeIds ?? [],
    emailsToNotifyUponApproval: initialData?.emailsToNotifyUponApproval ?? [''],
  }

  const handleSubmit = async (values: FormValues) => {
    const employeeIds = (values.employeeIds as string[]).filter((id) => id && id.trim() !== '')
    const filteredApprovers = (values.approverEmployeeIds as string[]).filter(
      (id) => id && id.trim() !== ''
    )
    const filteredEmails = (values.emailsToNotifyUponApproval as string[]).filter(
      (m) => m && m.trim() !== ''
    )

    const promotionData: PromotionRequestPayload = {
      employeeIds,
      newJobTitle: values.newJobTitle,
      newJobGradeId: values.newJobGradeId as string | undefined,
      newJobGrade: values.newJobGrade as string | undefined,
      newDepartmentId: values.newDepartmentId as string | undefined,
      newDepartment: values.newDepartment as string | undefined,
      newZoneId: values.newZoneId as string | undefined,
      newZone: values.newZone as string | undefined,
      newBranchId: values.newBranchId as string | undefined,
      newBranch: values.newBranch as string | undefined,
      newSalary: (values.newSalary as number) ?? 0,
      effectiveDate: values.effectiveDate as string,
      includesTransfer: Boolean(values.includesTransfer),
      approverEmployeeIds: filteredApprovers,
      emailsToNotifyUponApproval: filteredEmails,
    }

    const response = initialData
      ? await updatePromotion(initialData.id, promotionData)
      : await createPromotion(promotionData)

    if (response.code === 200 || response.code === 201) {
      confirmationDialog.showSuccess({
        title: `Promotion ${initialData ? 'Updated' : 'Created'}`,
        content: `You have successfully ${initialData ? 'updated' : 'created'} a promotion`,
        onConfirm: () => {
          push('/promotions/')
        },
      })
    } else {
      confirmationDialog.showError({
        title: 'Operation Failed',
        content: response.message ?? `Failed to ${initialData ? 'update' : 'create'} promotion`,
      })
    }
  }

  return (
    <SectionContainer>
      <PageHeader
        title={initialData ? 'Edit Promotion' : 'Create Promotion'}
        description={initialData ? 'Update the promotion details' : 'Create a new promotion record'}
      />

      <Formik<FormValues>
        key={initialData?.id || 'form'}
        initialValues={initialValues}
        validate={(values) => validateWithZod(values, zodSchema)}
        onSubmit={handleSubmit}
        enableReinitialize={true}
        validateOnBlur={false}
      >
        {({ errors, touched, isSubmitting, values, setFieldValue }) => {
          const employeeIds = (values.employeeIds as string[]) ?? []
          // Approvers are chosen from staff, excluding the employees being promoted.
          const approverOptions = employeeOptions.filter((o) => !employeeIds.includes(o.value))

          return (
            <Form className="space-y-4">
              {/* Employee Details Section */}
              <div className="bg-white rounded-lg p-6 space-y-6">
                <h2 className="text-xl font-semibold text-slate-900">Employee Information</h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Employee(s) - multi-select (single source of truth = the roster) */}
                  <MultiSelectCombobox
                    label="Employee Name(s)"
                    required
                    placeholder="Select one or more employees"
                    options={employeeOptions}
                    value={employeeIds}
                    onChange={(ids) => setFieldValue('employeeIds', ids)}
                    error={
                      touched.employeeIds && errors.employeeIds
                        ? (errors.employeeIds as string)
                        : false
                    }
                  />

                  {/* New Job Title - Using SelectField */}
                  <SelectField
                    label="New Job Title"
                    value={values.newJobTitleId as string}
                    options={designationOptions}
                    placeholder="Select job title"
                    onChange={async (value) => {
                      const label = designationOptions.find((o) => o.value === value)?.label ?? ''
                      await setFieldValue('newJobTitleId', value)
                      await setFieldValue('newJobTitle', label)
                    }}
                    error={touched.newJobTitleId && !!errors.newJobTitleId}
                    errorMessage={errors.newJobTitleId as string}
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* New Job Grade - Using SelectField */}
                  <SelectField
                    label="New Job Grade"
                    value={values.newJobGradeId as string}
                    options={jobGradeOptions}
                    placeholder="Select job grade"
                    onChange={async (value) => {
                      const label = jobGradeOptions.find((o) => o.value === value)?.label ?? ''
                      await setFieldValue('newJobGradeId', value)
                      await setFieldValue('newJobGrade', label)
                    }}
                    error={touched.newJobGradeId && !!errors.newJobGradeId}
                    errorMessage={errors.newJobGradeId as string}
                    required
                  />

                  {/* Branch - Using SelectField */}
                  <SelectField
                    label="Branch"
                    value={values.newBranchId as string}
                    options={branchOptions}
                    placeholder="Select branch"
                    onChange={async (value) => {
                      const label = branchOptions.find((o) => o.value === value)?.label ?? ''
                      await setFieldValue('newBranchId', value)
                      await setFieldValue('newBranch', label)
                    }}
                    error={touched.newBranchId && !!errors.newBranchId}
                    errorMessage={errors.newBranchId as string}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 md:grid-cols-2 gap-6">
                  {/* Zone - Using SelectField */}
                  <SelectField
                    label="Zone"
                    value={values.newZoneId as string}
                    options={zoneOptions}
                    placeholder="Select zone"
                    onChange={async (value) => {
                      const label = zoneOptions.find((o) => o.value === value)?.label ?? ''
                      await setFieldValue('newZoneId', value)
                      await setFieldValue('newZone', label)
                    }}
                    error={touched.newZoneId && !!errors.newZoneId}
                    errorMessage={errors.newZoneId as string}
                    required
                  />

                  {/* Department - Using SelectField */}
                  <SelectField
                    label="Department"
                    value={values.newDepartmentId as string}
                    options={departmentOptions}
                    placeholder="Select department"
                    onChange={async (value) => {
                      const label = departmentOptions.find((o) => o.value === value)?.label ?? ''
                      await setFieldValue('newDepartmentId', value)
                      await setFieldValue('newDepartment', label)
                    }}
                    error={touched.newDepartmentId && !!errors.newDepartmentId}
                    errorMessage={errors.newDepartmentId as string}
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700">
                      New Salary
                      <span className="text-destructive ml-1">*</span>
                    </label>
                    <AmountInput
                      name="newSalary"
                      prefix="GHS"
                      placeholder="0.00"
                      error={touched.newSalary && !!errors.newSalary}
                      className="h-10 w-full"
                    />
                  </div>
                  <DatePickerField
                    label="Effective Date"
                    value={values.effectiveDate as string}
                    onSelect={(date) => setFieldValue('effectiveDate', date)}
                    error={touched.effectiveDate ? (errors.effectiveDate as string) : undefined}
                    required
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    checked={Boolean(values.includesTransfer)}
                    onCheckedChange={(checked) => setFieldValue('includesTransfer', checked)}
                  />
                  <label className="text-sm font-medium text-slate-700">Include Transfer</label>
                </div>
              </div>

              {/* Approval & Notification Section */}
              <div className="bg-white rounded-lg p-6 w-full space-y-6">
                <h2 className="text-xl font-semibold text-slate-900">Approval &amp; Notification</h2>

                {/* Approvers - reuses MultiSelectCombobox */}
                <MultiSelectCombobox
                  label="Approvers"
                  required
                  placeholder="Select one or more approvers"
                  options={approverOptions}
                  value={(values.approverEmployeeIds as string[]) ?? []}
                  onChange={(ids) => setFieldValue('approverEmployeeIds', ids)}
                  error={
                    touched.approverEmployeeIds && errors.approverEmployeeIds
                      ? (errors.approverEmployeeIds as string)
                      : false
                  }
                  description="Select the approver(s) who must sign off on this promotion."
                />

                {/* Notify Departments Section */}
                <div className="flex flex-row w-full gap-2">
                  <div className="flex-1 space-y-2">
                    <label htmlFor="emailsToNotifyUponApproval" className="text-sm font-medium">
                      Notify Departments{' '}
                      <span className="text-gray-600 text-sm font-normal">
                        (Department mails only)
                      </span>
                    </label>
                    <FieldArray name="emailsToNotifyUponApproval">
                      {({ push, remove }) => (
                        <div className="space-y-1">
                          {Array.isArray(values.emailsToNotifyUponApproval) &&
                            values.emailsToNotifyUponApproval.map((_dep: string, index: number) => (
                              <div key={index} className="flex items-center gap-2 w-full">
                                <div className="flex-grow">
                                  <Field
                                    as={Input}
                                    name={`emailsToNotifyUponApproval[${index}]`}
                                    placeholder="e.g. HR, Finance, it@company.com"
                                    error={
                                      touched.emailsToNotifyUponApproval &&
                                      !!errors.emailsToNotifyUponApproval
                                    }
                                    className="w-full"
                                  />

                                  {touched.emailsToNotifyUponApproval &&
                                    errors.emailsToNotifyUponApproval && (
                                      <p className="text-sm text-red-600">
                                        {Array.isArray(errors.emailsToNotifyUponApproval)
                                          ? (errors.emailsToNotifyUponApproval as string[]).join(
                                              ', '
                                            )
                                          : (errors.emailsToNotifyUponApproval as string)}
                                      </p>
                                    )}
                                </div>

                                {Array.isArray(values.emailsToNotifyUponApproval) &&
                                  values.emailsToNotifyUponApproval.length > 1 && (
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => remove(index)}
                                      className="shrink-0"
                                    >
                                      <Trash className="h-4 w-4 text-red-500" />
                                    </Button>
                                  )}
                              </div>
                            ))}

                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => push('')}
                            className="hover:bg-transparent p-0"
                          >
                            <Plus className="h-4 w-4" />
                            Add another mail / department
                          </Button>
                        </div>
                      )}
                    </FieldArray>
                  </div>
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-4 pt-6 border-t border-slate-200">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => push('/promotions/')}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting} loading={isSubmitting}>
                  {initialData ? 'Save Changes' : 'Create Promotion'}
                </Button>
              </div>
            </Form>
          )
        }}
      </Formik>

      {confirmationDialog.renderDialog()}
    </SectionContainer>
  )
}

export default PromotionsForm
