'use client'

import { ListFilter } from 'lucide-react'
import { useState } from 'react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { cn } from '@/lib/utils'

export interface StatusFilterOption {
  /** The value committed to `selected` (commonly the API status as a string, e.g. "0"). */
  readonly value: string
  readonly label: string
}

interface StatusFilterProps {
  /** Selectable options. */
  readonly options: ReadonlyArray<StatusFilterOption>
  /** Currently-selected values. An empty array means "no filter / show all". */
  readonly selected: readonly string[]
  /** Fires with the next selection whenever the user toggles or clears. */
  readonly onChange: (next: string[]) => void
  /** Trigger label. Defaults to "Status". */
  readonly label?: string
  /** Popover heading. Defaults to "Filter by status". */
  readonly title?: string
  readonly align?: 'start' | 'center' | 'end'
  readonly className?: string
}

/**
 * Reusable filter button + popover with multi-select checkboxes.
 * Mirrors the design's status filter and is generic enough to reuse for any
 * "filter by <enum>" use case (promotions, transfers, job-title, exits…).
 *
 * Note on the API: GET /api/Promotions accepts a SINGLE `Status` integer, so a
 * caller that filters server-side should pass the first selected value (or omit
 * the param when empty). The component itself supports multi-select so it can
 * also filter client-side, or drive several requests, as needed.
 */
export function StatusFilter({
  options,
  selected,
  onChange,
  label = 'Status',
  title = 'Filter by status',
  align = 'end',
  className,
}: StatusFilterProps) {
  const [open, setOpen] = useState(false)
  const count = selected.length

  const toggle = (value: string) => {
    onChange(
      selected.includes(value) ? selected.filter((v) => v !== value) : [...selected, value]
    )
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={cn('gap-2 border-gray-300 text-gray-700', className)}
        >
          <ListFilter className="h-4 w-4 text-gray-500" />
          {label}
          {count > 0 && (
            <Badge
              variant="secondary"
              className="ml-0.5 h-5 min-w-5 justify-center rounded-full px-1.5 text-xs"
            >
              {count}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align={align} className="w-56 p-0">
        <div className="flex items-center justify-between border-b px-3 py-2.5">
          <span className="text-xs font-semibold uppercase tracking-wide text-gray-500">
            {title}
          </span>
          {count > 0 && (
            <button
              type="button"
              onClick={() => onChange([])}
              className="text-xs font-semibold text-primary hover:underline"
            >
              Clear
            </button>
          )}
        </div>
        <div className="flex flex-col p-1.5">
          {options.map((option) => {
            const isSelected = selected.includes(option.value)
            return (
              <button
                key={option.value}
                type="button"
                onClick={() => toggle(option.value)}
                className={cn(
                  'flex items-center gap-2.5 rounded-md px-2.5 py-2 text-left text-sm transition-colors',
                  isSelected ? 'bg-gray-50' : 'hover:bg-gray-50'
                )}
              >
                <Checkbox checked={isSelected} aria-label={option.label} />
                <span className="text-gray-800">{option.label}</span>
              </button>
            )
          })}
        </div>
      </PopoverContent>
    </Popover>
  )
}

export default StatusFilter
